import 'package:flutter/material.dart';
import '../data/property.dart';
import 'description.dart';
import 'property_info.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  final List<Property> properties = [
    Property(
      name: 'Luxury Villa',
      image: 'assets/image.png',
      price: 500000,
      description: 'A stunning villa with a sea view.',
    ),
    Property(
      name: 'Modern Apartment',
      image: 'assets/image_1.png',
      price: 200000,
      description: 'Stylish apartment in the city center.',
    ),
    Property(
      name: 'Cozy Cottage',
      image: 'assets/image_2.png',
      price: 150000,
      description: 'A quaint cottage perfect for families.',
    ),
    Property(
      name: 'Beachfront Property',
      image: 'assets/image_3.png',
      price: 800000,
      description: 'Direct access to the beach!',
    ),
    Property(
      name: 'Country House',
      image: 'assets/image_4.png',
      price: 300000,
      description: 'A serene escape in the countryside.',
    ),
    Property(
      name: 'Penthouse Suite',
      image: 'assets/image_5.png',
      price: 600000,
      description: 'Luxury living at its finest.',
    ),
    Property(
      name: 'Family Home',
      image: 'assets/image_6.png',
      price: 400000,
      description: 'A perfect home for your family.',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Altaf Properties'),
        backgroundColor: Colors.teal[300],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20.0, 20.0, 20.0, 10.0),
          child: ListView.builder(
            itemCount: properties.length,
            itemBuilder: (context, index) {
              Property property = properties[index];
              return Card(
                elevation: 5,
                margin: const EdgeInsets.symmetric(vertical: 10),
                child: ListTile(
                  contentPadding: const EdgeInsets.all(16.0),
                  leading: ClipOval(
                    child: Image.asset(property.image, width: 50, height: 50, fit: BoxFit.cover),
                  ),
                  title: Center(
                    child: Text(
                      property.name,
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                  ),
                  subtitle: Center(
                    child: Text(
                      'OMR ${property.price}',
                      style: const TextStyle(fontSize: 16, color: Colors.grey),
                    ),
                  ),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => Description(property: property),
                      ),
                    );
                  },
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
