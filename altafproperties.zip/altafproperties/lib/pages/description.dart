import 'package:flutter/material.dart';
import '../data/property.dart';
import 'property_info.dart';

class Description extends StatelessWidget {
  final Property property;

  const Description({super.key, required this.property});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(property.name),
        backgroundColor: Colors.teal[300],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Image.asset(property.image),
            const SizedBox(height: 20),
            Text(
              property.name,
              style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 10),
            Text(
              property.description,
              style: const TextStyle(fontSize: 18),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            Text(
              'OMR ${property.price}',
              style: const TextStyle(fontSize: 22, color: Colors.green),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => Property_info(property: property),
                  ),
                );
              },
              style: ElevatedButton.styleFrom(backgroundColor: Colors.teal[300]),
              child: const Text('More Info'),
            ),
          ],
        ),
      ),
    );
  }
}
